# -*- coding: utf-8 -*-
"""
=========================================
ftt_p_dspch.py
=========================================
Power generation dispatching FTT module.


Functions included:
    - dspch
        Calculate dispatching

"""

# Third party imports
import numpy as np
from numba import njit, prange




# %% dispatch function
# -----------------------------------------------------------------------------
# ------------------------- DISPATCH of capacity ------------------------------
# -----------------------------------------------------------------------------

# Jit-in-time compilation. Comment this line out if you need to debug *in* the function
@njit(cache=True, parallel=True)  # Removed fastmath=True to prevent inf/nan from unsafe float ops
def dspch(MWDD, MEWS, MKLB, MCRT, MEWL, MWMC_lag, MMCD_lag, num_regions, num_techs, num_loadbands):
    """
    Calculates dispatch of capacity.

    The function estimates an allocation of power production between
    technologies and load bands.

    Parameters
    -----------
    MWDD: NumPy array
        Matrix of load band tech suitability
    MEWS: NumPy array
        Market shares for the current year
    MKLB: NumPy array
        Capacity by load band
    MCRT: NumPy array
        Curtailment of VRE (% of generation)
    MEWL: NumPy array
        Load factors (%)
    MWMC_lag: NumPy array
        Lagged marginal costs
    MMCD_lag: NumPy array
        Lagged standard deviation of marginal costs
    num_regions: int
        Number of regions
    num_techs: int
        Number of technologies
    num_loadbands: int
        Number of load bands

    Returns
    ----------
    MSLB: NumPy array
        Shares of capacity by tech x load band
    MLLB: NumPy array
        Load factors (%) by tech x load band
    MES1: NumPy array
        Upper market share limitation (1) -- virtually turned off
    MES2: NumPy array
        Lower market share limitation (2)
    """

    # dd is shorthand for load band suitability of different technologies
    dd = MWDD[0, :, :]

    # Technology logic identifiers
    s_not_var = 1.0 - dd[:, 5]

    # Convergence criterion
    crit = 0.0001

    # Initialize variables to return (for numba)
    MSLB = np.zeros((num_regions, num_techs, num_loadbands))
    MLLB = np.zeros((num_regions, num_techs, num_loadbands))
    MES1 = np.zeros((num_regions, num_techs, 1))
    MES2 = np.zeros((num_regions, num_techs, 1))

    for r in prange(num_regions):

        p_tech = np.zeros((num_techs, num_loadbands))
        p_grid = np.zeros((num_techs, num_loadbands))
        d_slb = np.zeros((num_techs, num_loadbands))
        cflb = np.zeros((num_techs, num_loadbands))
        q = 0
        # Shares of capacity by tech
        s_i = s_not_var * MEWS[r, :, 0]
        # Shares of capacity by load band
        klb = np.zeros((num_loadbands))
        klb[:5] = MKLB[r, :5, 0]
        # Average marginal cost
        m0 = np.sum(s_i * MWMC_lag[r, :, 0])
        
        # First, allocate nuclear (tech 0) to the baseload band
        if s_i[0] > 0.0:
            if klb[0] <= s_i[0]:
                MSLB[r,0,0] = MSLB[r,0,0] + klb[0]
                s_i[0] = s_i[0] - klb[0]
                klb[0] = 0.0
            else:
                klb[0] = klb[0] - s_i[0]
                MSLB[r,0,0] = MSLB[r,0,0] + s_i[0]
                s_i[0] = 0.0
                
            # Allocate any remaining nuclear to the next load band
            if klb[1] > 0.0 and s_i[0]>0.0:
                if klb[1]<= s_i[0]:
                    MSLB[r,0,1] = MSLB[r,0,1] + klb[1]
                    s_i[0] = s_i[0] - klb[1]
                    klb[1] = 0.0
                else:
                    klb[1] = klb[1] - s_i[0]
                    MSLB[r,0,1] = MSLB[r,0,1] + s_i[0]
                    s_i[0] = 0.0            
                

        # Technologies bid for generation time: weighted MNL
        # Constrained by size of load bands and available tech shares,
        # so allocate in an iterative process to try to find allocation closest
        # to preferences. Probabilistic 'college admissions'/'stable matching'
        while (s_i.sum() > crit and q < 50):

            for i in range(num_loadbands - 1): # NOT intermittent renewables
                # TODO: In FORTRAN, MMC1 is chosen (which does not include negative carbon prices for BECCS). Switch either. 
                sig = np.sqrt(np.sum(dd[:,i] * MMCD_lag[r, :, 0]**2 * MEWS[r, :, 0]))
                exponent = -(MWMC_lag[r, :, 0] - m0) / sig
                fn = np.zeros((num_techs))
                # Approximate exponential
                fn[np.abs(exponent) < 20] = np.exp(exponent[np.abs(exponent) < 20])
                fn[exponent >= 20] = 1e9
                fn[exponent <= -20] = 1e-9
                
                # Multinomial logit or simplification
                if (np.sum(dd[:,i] * s_i) > 0 and sig > 0.001 and np.sum(dd[:,i] * s_i * fn) > 0):

                    p_tech[:, i] = dd[:,i]*s_i*fn / np.sum(dd[:,i]*s_i*fn)

                else:

                    p_tech[:, i] = np.zeros((num_techs))

            # Grid operator has preferences amongst what is bid for
            for k in range(num_techs):

                # p_grid is likelihood grid accepts bid from tech k
                sig = np.sqrt(np.sum(dd[k,:]*MMCD_lag[r, k, 0]**2))

                if (dd[k,5] == 0 and np.sum(dd[k,:]*klb) > 0 and sig > 0.001):

                    p_grid[k,:] = dd[k,:]*klb / np.sum(dd[k,:]*klb)

                else:

                    p_grid[k,:] = np.zeros((num_loadbands))

            # Increment q
            q += 1
            # Allocate one round of generation to load bands according to p_grid, p_tech
            for i in range(num_loadbands - 1):

                for k in range(num_techs):

                    d_slb[k, i] = np.abs(np.minimum(np.abs(s_i[k]), np.abs(klb[i])) * p_tech[k, i] * p_grid[k, i])

            d_slb[:, 5] = np.zeros((num_techs))
            # Cumulative allocations each round
            MSLB[r, :, :] = MSLB[r, :, :] + d_slb
            # Remove allocation from what's left per tech and load band
            s_i = s_i - np.sum(d_slb, axis=1)
            klb = klb - np.sum(d_slb, axis=0)

        # Capacity of renewables
        for index in range(len(MWDD[0, :, 5])):
            if MWDD[0, index, 5]:
                MSLB[r, index, 5] = MEWS[r, index, 0]

        # Capacity factors by load band (definitionally)
        cflb[:, 0] = 7500 / 8766
        cflb[:, 1] = 4400 / 8766
        cflb[:, 2] = 2200 / 8766
        cflb[:, 3] = 700 / 8766
        cflb[:, 4] = 80 / 8766
        cflb[:, 5] = np.zeros((num_techs))
        
        for index in range(len(MWDD[0,:,5])):
            if MWDD[0,index,5]:
                cflb[index, 5] = MEWL[r, index, 0] # * (1 - MCRT[r,index,0])
        cflb = np.where(cflb==0, 1, cflb)

        # Save in data dict
        MLLB[r, :, :] = cflb * 1

        # Upper share limit: set to ones for now (no upper limit, but
        # resistance to 100% market shares for any single tech)
        MES1[r, :, 0] = np.ones(num_techs)

        # Lower share limits
        # TODO: Are these compatible with storage cost incorporation? Maybe not...
        # Difference between availability (minus taken by other LB) and requirement per LB
        # Note this quantity is essentially what Gmin(i,j) takes tanh of
        grid_lim = np.zeros((5))

        grid_lim[4] = np.sum(dd[:, 4] * MEWS[r, :, 0]) - MKLB[r, 4, 0]
        grid_lim[3] = np.sum(dd[:, 3] * MEWS[r, :, 0]) - np.sum(MKLB[r, 3:5, 0])
        grid_lim[2] = np.sum(dd[:, 2] * MEWS[r, :, 0]) - np.sum(MKLB[r, 2:5, 0])
        grid_lim[1] = np.sum(dd[:, 1] * MEWS[r, :, 0]) - np.sum(MKLB[r, 1:5, 0])
        
        # No lower limit for baseload band
        grid_lim[0] = np.sum(dd[:, 0] * MEWS[r, :, 0]) - np.sum(MKLB[r, 0:5, 0])
        
        # Temp is shares minus grid_lim for suitable LB
        temp = np.zeros((num_techs, num_loadbands))
        for i in range(1, num_loadbands - 1):
            temp[:,i] = dd[:,i] * (MEWS[r,:,0] - grid_lim[i])
        
        # For each tech, take largest value in temp or shares, whichever is less
        for i in range(num_techs):
            MES2[r, i, 0] = min(np.max(temp[i, :]), MEWS[r, i, 0])

    return MSLB, MLLB, MES1, MES2


def calculate_load_factors_from_dispatch(data, titles):
    """
    Calculate technology load factors from dispatch results across load bands.

    Updates data['MEWL'] and data['Gen_by_lb'] in place.
    """

    # Total electricity demand, convert from PJ to GWh
    tot_elec_dem = data['MEWDX'][:,7,0] * 1000/3.6

    # Generation by tech x load band = share * height * total demand
    share_x_height = data['MSLB'] * data['MLLB']
    glb3 = share_x_height * tot_elec_dem[:, np.newaxis, np.newaxis]

    # Capacity by tech x load band = generation / height
    klb3 = np.divide(glb3, data['MLLB'],
                     out=np.zeros_like(glb3),
                     where=data['MLLB'] != 0)

    # Calculate load factors MEWL: total generation / total capacity
    total_capacity = np.sum(klb3, axis=2)
    total_generation = np.sum(glb3, axis=2)

    data['MEWL'][:, :, 0] = np.divide(
        total_generation, total_capacity,
        out=np.zeros_like(total_generation),
        where=total_capacity > 0
    )

    # Store generation by load band (region x tech x lb)
    data['Gen_by_lb'] = glb3

    # Use default load factors for near-zero values (matching Cascading's simulation period behavior)
    # Cascading line 664: uses <= 0.0001 threshold in simulation period
    zero_lf = data['MEWL'][:, :, 0] <= 0.0001
    data['MEWL'][:, :, 0] = np.where(
        zero_lf,
        data['MWLO'][:, :, 0],
        data['MEWL'][:, :, 0]
    )
    